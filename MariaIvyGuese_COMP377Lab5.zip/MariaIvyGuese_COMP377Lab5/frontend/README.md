# 📚 Lab 5 – Full‑Stack Agentic RAG Chatbot
**Author:** Maria Ivy Guese  
**Course:** COMP 377 – AI for Software Developers

---

## 📌 Overview
This project is a **full‑stack Retrieval‑Augmented Generation (RAG) chatbot** that answers questions based on the contents of `academic_policy.txt`.  
It uses **Flask** (backend) + **LangChain** + **FAISS** + **Google Generative AI** for the AI logic, and **React with Vite** (frontend) for the user interface.

---

## 🗂 Modular Project Structure

MariaIvyGuese_COMP377Lab5/
├── backend/
│ ├── data/
│ │ └── academic_policy.txt # Knowledge source for chatbot
│ ├── app.py # Flask backend with RAG pipeline
│ ├── requirements.txt # Python dependencies
│ ├── .env.template # Template for environment variables (no real keys)
│ └── .env # Local environment variables (contains real API key, ignored by Git)
│
├── frontend/
│ └── rag-chatbot-frontend/
│ ├── src/
│ │ ├── components/ # React components (UI building blocks)
│ │ ├── App.jsx # Main chat UI logic
│ │ ├── App.css # Styling for the chat interface
│ │ └── main.jsx # Entry point for React app
│ ├── index.html # App HTML shell
│ ├── package.json # Frontend dependencies
│ └── vite.config.js # Vite build tool config
│
└── README.md # Project documentation


---

## 🔑 `.env.template` Explanation
The `.env.template` file contains **placeholders** for all environment variables needed in the project — without exposing real secrets.  
Developers copy it to `.env` and replace the placeholder values with their actual credentials.

**Example:**
.env.template
GOOGLE_API_KEY=your_google_api_key_here

.env


This ensures:
- API keys are not hardcoded in the source code.
- Secrets are kept private.
- Project setup is consistent across machines.

---

## ⚙️ Installation & Setup

### 1. **Backend Setup** (Flask + LangChain)

cd backend
pip install -r requirements.txt
cp .env.template .env

Edit .env to add your actual GOOGLE_API_KEY
python app.py


### 2. **Frontend Setup** (React + Vite)
cd frontend/rag-chatbot-frontend
npm install
npm run dev -- --host


By default:
- Backend runs on **localhost:5000**
- Frontend runs on **localhost:5173**

---

## 🚀 Usage
1. Start **backend** and **frontend** in separate terminals.
2. Open the frontend URL in your browser.
3. Type a question related to the **academic policy** in the chat box.
4. The chatbot processes the question using the RAG pipeline and returns an answer.
   - **In‑context questions** → Detailed, accurate answers from `academic_policy.txt`
   - **Out‑of‑context questions** → Polite message saying no information is available

---

## 🧠 How It Works
1. **Document Loading** – `academic_policy.txt` is read and split into chunks.
2. **Embeddings** – Chunks are embedded via Google Generative AI embeddings.
3. **Vector Store** – Embeddings are stored in a FAISS database for fast retrieval.
4. **Retrieval‑Augmented Generation** – LangChain pulls relevant chunks and sends them, with the query, to Gemini for answering.
5. **Frontend Display** – React UI shows the user query and chatbot’s response in a conversation format.

---

## 📌 Features
- Modular **frontend** and **backend** structure
- Secure `.env` configuration
- Chat‑style UI for smooth interaction
- CORS‑enabled backend for cross‑origin requests
- Custom prompt to keep answers within context

---
